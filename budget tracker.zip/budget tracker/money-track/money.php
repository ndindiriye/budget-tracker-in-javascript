<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="money/money.css">
    <link rel="shortcut icon" href="budgeting.png">
</head>

<body>

<h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        <!--<a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>-->
        <a href="logout.php" class="btn btn-danger ml-3" style="float:right;height:40px;width:40px;font-size:12px;margin-right:30px;background-color:black;" >Sign Out</a>
    </p>

    <div class="header">
        <h1>MANAGE MY MONEY</h1>
    </div>

    <div class="main">
        <div class="container">
            <div class="top_card">
                <p>Your Current Balance</p>
                <h3><span id="symbol">$</span><span id="balance">10500</span></h3>
            </div>


            <div class="form">
                <h3>Add new transaction</h3>

                <div class="form-group">
                    <label for="transaction_name">Name</label>
                    <input type="text" name="transaction_name" placeholder="add new activity" id="transaction_name">
                </div>

                <div class="form-group radio">
                    <label for="transaction_type">Type</label>
                    <div class="radio_group">
                        <input type="radio" value="income" name="transaction_type" id="income" checked>
                        <label for="transaction_type">Income</label>
                    </div>
                    <div class="radio_group">
                        <input type="radio" value="expense" name="transaction_type" id="expense" placeholder="Expense">
                        <label for="transaction_type">Expense</label>
                    </div>

                </div>

                <div class="form-group">
                    <label for="transaction_amount">Amount</label>
                    <input type="number" placeholder="300" name="transaction_amount" id="transaction_amount">
                </div>

                <button class="btn btn-block" id="add_transaction">Add Transaction</button>

                <button class="btn btn-block" id="cancel_edit" onclick="cancelEdit()">Cancel Edit</button>

            </div>

            <p class="second_heading">Your Transactions:</p>

            <div class="conatiner_of_list_of_transactions">

                <ul id="list_of_transactions">
                    <li class="transaction income">
                        <p>Earned this month</p>
                        <div class="right">
                            <p>+$100</p>
                            <button class="link">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="link">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </li>
                </ul>
            </div>

        </div>
    </div>

    <div class="footer">
        &copy;2022 By eric
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha512-RXf+QSDCUQs5uwRKaDoXt55jygZZm2V++WUZduaU/Ui/9EGp3f/2KZVahFZBKGH0s774sd3HmrhUy+SgOFQLVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="app.js"></script>
</body>

</html>
