// javascript for details.html

const id = new URLSearchParams(window.location.search).get('id');


const todocontent = document.querySelector('.details')
const deleteBtn = document.querySelector('.deleteBtn');



const getDetails = async() => {
    const res = await fetch('http://localhost:3000/todos/' + id);
    //const res = await fetch(url + id);
    const todo = await res.json();
    console.log(todo)
    let template = `
    <div class="todos">
    <h2>${todo.title}</h2>
    <p>${todo.body}</p>
    </div>
   `;
    todocontent.innerHTML = template;
};
deleteBtn.addEventListener("click", async() => {
    await fetch('http://localhost:3000/todos/' + id, {
        method: "DELETE"
    });


    window.location.replace('index1.php');
})

window.addEventListener('DOMContentLoaded', () => getDetails());