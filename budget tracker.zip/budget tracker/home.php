<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>money track system </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">
    
    <style>
        .home{
            background-image:url("mo1.png");
            background-repeat:no-repeat;
            background-size:cover;
           height:70rem;
           margin-bottom:-50px;
        }
        .box {
    margin-top: 0rem;
    font-size: 2rem;
    background: none;
    padding: 0rem;
    color: #16a085;
    height: 10rem;
}

.header .navbar a{
    font-size: 1.7rem;
    color: var(--light-color);
    margin-left: 2rem;
    
}
.content h2{
    font-size:26px !important;
    margin-top:6px;
}
.content p{
    font-size:17px !important;
}

.header .navbar a:hover{
    color: var(--green);
    transform:35px;
    background:var(--green);
    radius:6em;
    color:black !important;
    
}

.header{
    background:#ffe;
}
.how{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    background-color: white;
    display:flex;
}
.how h1{
    font-size:18px;
}


.container{
    width: 85vmin;
    height:40rem;
    position: absolute;
    transform: translate(-50%,-50%);
    top: 100%;
    left: 50%;
    overflow: hidden;
    border: 10px solid #ffffff;
    border-radius: 8px;
    box-shadow: 10px 25px 30px rgba(0,0,0,0.3);
    margin-top:30rem;
    background:white;
}

.wrapper{
    width: 100%;
    display: flex;
    animation: slide 15s infinite;
}
.wrapper img {
    width:100%;
    height:100%;
}
img{
    width: 100%;
}
@keyframes slide{
    0%{
        transform: translateX(0);
    }
    25%{
        transform: translateX(0);
    }
    30%{
        transform: translateX(-100%);
    }
    50%{
        transform: translateX(-100%);
    }
    55%{
        transform: translateX(-200%);
    }
    75%{
        transform: translateX(-200%);
    }
    80%{
        transform: translateX(-300%);
    }
    100%{
        transform: translateX(-300%);
    }
    
}




.container1{
 	max-width: 1170px;
 	width: 100%;
 	margin:auto;
 }

 .container1{
 	height: 100vh;
 	background-image: url("images/bg.jpg");
 	background-size: cover;
 	background-position: center;
 	display: flex;
 	flex-wrap: wrap;
 	padding:50px 15px;
 	position: relative;
     margin-left:40rem;
 }


  .home-text{
 	text-align: center;
 	position: relative;
 	z-index: 2;
 }

 .home-text h1{
	color:#ffffff;
	font-size: 50px;
	color:#ffffff;
	line-height: 56px;
	font-weight: 700;
	margin:0 0 20px;
}
 .home-text p{
	margin:0;
	overflow: hidden;
}
.home-text h1{
    color:var(--green);
font-size:2rem;
}
 .home-text p span{
    font-size: 12px;
    color:black;
    font-weight: 700;
    display: inline-block;
    line-height: 46px;
    display: none;
}

.home-text p span.text-in{
	display: block;
	animation: textIn .8s ease;
}
 .home-text p span.text-out{
	animation: textOut .8s ease;
}
/* blog styles */

.blogs {
    background: white;
    font-family: 'Roboto';
    color: #444;
   
    margin: 10px auto;
    padding: 10px;
    font-size:14px;
    
}

.blogs .nav1 {
    display: flex;
    justify-content: space-between;
    margin-right: 10rem;
    padding:20px;
  
}
.blogs .nav1 h1 {
    font-size:24px;
}
.blogs button{
    
}

.blogs .nav1 a {
    color: white;
    text-decoration: none;
    background: #36cca2;
    padding: 10px;
    border-radius: 10px;
    width:500px;
}

.blogs form {
    max-width: 100%;
    display: flex;
}

.blogs .todos input,
textarea {
    display: block;
    margin: 16px 0;
    padding: 6px 10px;
    width: 100%;
    border: 1px solid #ddd;
    font-family: 'Roboto';
}

textarea {
    min-height: 200px;
}
.todos {
    padding:60px;
    display:inline-block;
    padding-right:40px;
    
}
@keyframes textIn{
	0%{
		transform: translateY(100%);
	}
	100%{
		transform: translateY(0%);
	}
}
@keyframes textOut{
	0%{
		transform: translateY(0%);
	}
	100%{
		transform: translateY(-100%);

	}
}


.content{
    margin-top:-20rem;
    margin-right:3rem;
}
.content a{
    margin-right:10px !important;  
    margin-left:8rem;
}


.footer-distributed{
	background: var(--green);
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;
	padding: 55px 50px;
    
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

.footer-distributed h3{
	color:  #ffffff;
	font: normal 36px 'Open Sans', cursive;
	margin: 0;
}

.footer-distributed h3 span{
	color:  lightseagreen;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
  font-weight:400;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #222;
	font-size: 14px;
	font-weight: normal;
	margin: 0;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
  font-weight:400;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  lightseagreen;
	text-decoration: none;;
}

.footer-distributed .footer-links a:before {
  content: "|";
  font-weight:300;
  font-size: 20px;
  left: 0;
  color: #fff;
  display: inline-block;
  padding-right: 5px;
}

.footer-distributed .footer-links .link-1:before {
  content: none;
}

/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 20px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 35px;
	height: 35px;
	cursor: pointer;
	background-color:  white;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}
    .foot{
        background-color:grey;
    }

/* media queries for all  */
@media (max-width:991px){

html{
    font-size: 55%;
}

.header{
    padding: 2rem;
}

section{
    padding:2rem;
}

}

@media (max-width:768px){

#menu-btn{
    display: initial;
}

.header .navbar{
    position: absolute;
    top:115%; right: 2rem;
    border-radius: .5rem;
    box-shadow: var(--box-shadow);
    width: 30rem;
    border: var(--border);
    background: #fff;
    transform: scale(0);
    opacity: 0;
    transform-origin: top right;
    transition: none;
}

.header .navbar.active{
    transform: scale(1);
    opacity: 1;
    transition: .2s ease-out;
}

.header .navbar a{
    font-size: 2rem;
    display: block;
    margin:2.5rem;
}

}

@media (max-width:450px){

html{
    font-size: 40%;
    width:80%;
}
footer{
    height:10%;
}
header{
    width:70%;
}
.how{
    width:70%;
}

}




        </style>

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> MY POCKET PLANNER. </a>

    <nav class="navbar">
        <a href="#">Home</a>
        <a href="#how">how it works</a>
        <a href="#blogs">blogs</a>
    </nav>


    <div id="menu-btn" class="fas fa-bars"></div>

</header>



<section class="home" id="home">

    <div class="image">
      
    </div>

    <div class="content">
       <h3>did you worried about using your money wiselly?</h3> 
       <h2> the solution is near you!</h2>
        <p>this is a platform which helps you to manage your income and expenses privatelly!</p>
        <a href="login.php" class="btn"> get started <span class="fas fa-chevron-right"></span> </a>
       
    </div>

</section>




<section class="how" id="how">

    <h1 class="heading">getting started with <span>our application</span> </h1>

    <div class="container1">
        <div class="row">
            <div class="home-text">
                 <h1>How can I use this application?</h1>
                 <p class="animate-text">
                    <span>firstly click on get started</span>
                    <span>if you have account login if not register</span>
                    <span>register with your credentials then login</span>
                    <span>when you login you can manage your expenses </span>
                    <span>then logout</span>
                 </p>
            </div>
        </div>
     </div>


    <div class="container">
    <div class="wrapper">
     
   <img src="capture.png">
   <img src="capture1.png">
   <img src="capture2.png">
   <img src="capture3.png">
   <img src="out.png">
  
 </div>
</div>     
            
        















</section>


<section id="blogs" class="blogs"> 

<nav class="nav1">
        <h1><i class="fa fa-home" aria-hidden="true"></i> users review</h1>
      
        <a href="blogs\create.php">Add a new idea</a>
    </nav>

    <div class="todos">
        <!-- inject blogs here from js -->
    </div>
</section>
<section class="foot">
<footer class="footer-distributed">

			<div class="footer-left">

				<h3>Company<span>logo</span></h3>

				<p class="footer-links">
					<a href="#" class="link-1">Home</a>
					
					<a href="#blogs">Blog</a>
				

				
					<a href="#how">how it works</a>
					
					
					
					<a href="#phone">Contact</a>
				</p>

				<p class="footer-company-name">mypocket © 2022</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>KG 47</span> kigali,rwanda</p>
				</div>

				<div id="phone">
					<i class="fa fa-phone"></i>
					<p>+250780707004</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@mypocket.com">support@mypocket.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span></span>
					this web will help the user to manage his budget efficientlly
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-github"></i></a>

				</div>

			</div>

		</footer>
</section>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>
         const txts=document.querySelector(".animate-text").children,
               txtsLen=txts.length;
           let index=0;
          const textInTimer=3000,
                textOutTimer=2700;

         function animateText() {
            for(let i=0; i<txtsLen; i++){
              txts[i].classList.remove("text-in","text-out");  
            }
            txts[index].classList.add("text-in");

            setTimeout(function(){
                txts[index].classList.add("text-out");              
            },textOutTimer)

            setTimeout(function(){

              if(index == txtsLen-1){
                  index=0;
                }
               else{
                   index++;
                 }
                animateText();
            },textInTimer); 
         }
         
         window.onload=animateText;
   
</script>
<script src="blogs\index.js"></script>
</body>


</html>