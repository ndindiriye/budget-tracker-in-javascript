const id = new URLSearchParams(window.location.search).get('id');
const form = document.querySelector('form');
const url = ('http://localhost:3000/todos/' + id);

const editdata = async(e) => {
    // alert('hello');
    e.preventDefault();
    //const edit = await fetch('http:/ / localhost: 3000 / todos / ' + id); {
    //const todo = await edit.json();
    // console.log(todo);
    //form.title.value = todo.title;
    //form.body.value = todo.body;

    await fetch(url, {
        method: 'PUT',
        body: JSON.stringify({
            title: form.title.value,
            body: form.body.value,
            likes: 0
        }),
        headers: { 'Content-Type': 'application/json' },
    });
    window.location.replace('index1.php');



    //console.log(edit)
}
form.addEventListener('submit', editdata);
window.addEventListener('DOMContentLoaded', async(e) => {
    e.preventDefault();
    const res = await fetch(url);
    const todo = await res.json();
    form.title.value = todo.title;
    form.body.value = todo.body;

})

//const form = document.querySelector('form');
//console.log(form.body);







//window.addEventListener('DOMContentLoaded', () => editdata());