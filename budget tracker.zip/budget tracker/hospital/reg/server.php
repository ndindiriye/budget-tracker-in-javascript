<?php
$db = mysqli_connect('localhost','root','','registration');
if(isset($_POST['register']))
{
 $username=mysql_real_escape_string($_POST['username']); 
 $email=mysql_real_escape_string($_POST['email']);  
 $password=mysql_real_escape_string($_POST['password']);  
 $password2=mysql_real_escape_string($_POST['password2']);  
 if (count($erros)==0)
 {
     $password=md5($password);
     $sql="insert into users(username,email,password)
     valeus('$username','$email','$passwor')";
     mysqli_query($db,$sql);
 }  
}
?>
