// javascript for index.html
const url = 'http://localhost:3000/todos/';
const conteiner = document.querySelector('.todos');

const getingtodo = async() => {

    const res = await fetch(url);
    const todos = await res.json();

    let template = '';

    todos.forEach(todo => {
        template += `
    <div class="todos">
    <h2>${todo.title}</h2>
    <p><i onclick="likesclicked(${todo.id})" class="fa fa-thumbs-up" aria-hidden="true" style="color:green; margin-right:0.5em" ></i><small>${todo.likes} likes</small></p>
    <p>${todo.body.slice(0,50)}</p>
    <a href="details.php?id=${todo.id}"><p>read more<p></a>
    
       </div>
   `;
    });
    conteiner.innerHTML = template;
};
const likesclicked = async(todo_id) => {
    const res = await fetch(url + todo_id);
    const todo = await res.json()



    await fetch(url + todo_id, {
        method: "PUT",
        body: JSON.stringify({
            title: todo.title,
            body: todo.body,
            likes: todo.likes + 1


        }),

        headers: {
            'Content-Type': "application/json "
        }
    })


}



window.addEventListener('DOMContentLoaded', () => getingtodo());