<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>blogs</title>
</head>

<body>

    <div class="details">
        <!-- inject blog details here -->
    </div>
    <button class="deleteBtn" style=" background: transparent;
    border: none !important;
    font-size:0;">Delete</button>

    <script src="details.js"></script>
</body>

</html>