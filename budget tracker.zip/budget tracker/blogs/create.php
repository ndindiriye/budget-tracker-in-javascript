<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Javascript | Advanced</title>
  <style>
  @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');

/* base styles */

body {
    background: #eee;
    font-family: 'Roboto';
    color: #444;
    max-width: 960px;
    margin: 100px auto;
    padding: 10px;
}

nav {
    display: flex;
    justify-content: space-between;
    margin-right: 100rem;
}

nav h1 {
    margin: 0;
}

nav a {
    color: white;
    text-decoration: none;
    background: #36cca2;
    padding: 10px;
    border-radius: 10px;
}

form {
    max-width: 200px;
    display: block;
  
}

input,
textarea {
    display: block;
    margin: 16px 0;
    padding: 6px 10px;
    width: 100%;
    border: 1px solid #ddd;
    font-family: 'Roboto';
}

textarea {
    min-height: 200px;
}
</style>
</head>

<body>
  
  <h1>leave a comment</h1>

  <form>
    <input type="text" name="title" required placeholder="your name">
    <textarea name="body" required placeholder="your detailed idea"></textarea>
    <button>Create</button>
  </form>

  <script src="create.js"></script>
</body>
</html>