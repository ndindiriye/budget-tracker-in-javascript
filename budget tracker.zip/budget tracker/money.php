<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Expense Tracker</title>
        <link href="https://fonts.googleapis.com/css2?family=Rubik&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="money-track/index.css">
    <style>

:root {
    --box-shadow: 0px 1px 4px 1px rgba(199, 199, 199, 1);
    --income:#16a085;
    --expense: red;
}

body {
    font-family: 'Rubik', 'sans-serfi';
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border: solid;
    border-color: green;
   
}
p a{
    float:left;
    color:black;
    font-weight:bold;
    margin-left:60rem;
    background:green;
    text-align:center;
}

.app {
    border: solid;
    border-color: green;
    width:30rem;
    padding-left:3rem;
    padding-right:3rem;
}

.app h1 {
    text-align: center;
    color: green;
}

h2 {
    font-size: 1.2em;
    text-transform: uppercase;
    margin-bottom: 10px;
}

.balance-container #balance {
    font-size: 1.5em;
    
}
.balance-container{
    
    padding:2em;
}

.cashflow-container {
    display: flex;
    box-shadow: var(--box-shadow);
    align-items: center;
    justify-content: center;
    padding-bottom: 20px;
    padding-top: 20px;
    margin-top: 20px;
}

.income-container {
    border-right: 1px solid ;
    padding-right: 20px;
}

.expense-container {
    padding-left: 20px;
}

#income,
#expense {
    font-size: 1.3em;
}

#income {
    color: var(--income);
}

#expense {
    color: var(--expense);
}

.transaction-container {
    margin-top: 40px;
}

#transaction {
    list-style: none;
    margin: 0;
    padding: 0;
}

#transaction li {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 10px;
    margin-bottom: 10px;
    box-shadow: var(--box-shadow);
}

#transaction li span {
    display: inline-block;
    color: white;
    padding: 5px;
    border-radius: 3px;
    margin-right: 5px;
}

#transaction li .income-amt {
    background-color: var(--income);
}

#transaction li .expense-amt {
    background-color: var(--expense);
}

#transaction li button {
    padding: 5px 10px 5px 10px;
}

.form-container {
    margin-top: 40px;
}

.form-container form {
    display: flex;
    flex-direction: column;
}

.form-container form label {
    padding-bottom: 10px;
}

.form-container form input {
    height: 25px;
    margin-bottom: 10px;
}

.form-container form button {
    border: none;
    padding: 10px;
    margin-bottom: 10px;
    font-size: 1em;
    text-transform: uppercase;
    color: white;
}

#incomeBtn {
    background-color: var(--income);
}

#expenseBtn {
    background-color: var(--expense);
}

    </style>
    </head>
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        <!--<a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>-->
        <a href="logout.php" class="btn btn-danger ml-3" style="float:right;height:40px;width:40px;font-size:12px;margin-right:10px;background-color: #16a085;" >sign Out</a>
    </p>
    <body style="background:white;">
        <div class="app">
      
            <h1>Expense Tracker</h1>

            <div class="balance-container">
                <h2>Your Balance</h2>
                <div id="balance">rwf1000</div>
                <div class="saving">
                <h2>savings</h2>
                <div id="saving">rwf1000</div>
            </div>
            </div>
            
           

            <div class="cashflow-container">
                <div class="income-container">
                    <h2>Income</h2>
                    <div id="income">rwf1200</div>
                </div>
                <div class="expense-container">
                    <h2>Expense</h2>
                    <div id="expense">rwf200</div>
                </div>
            </div>

            <div class="transaction-container">
                <h2>Transaction History</h2>
                <ul id="transaction">
                    
                </ul>
            </div>

            <div class="form-container">
                <h2>Add new transaction</h2>
                <form onsubmit="return false;">
                    <label for="name">Name</label>
                    <input id="name" type="text">
                    <label for="amount">Amount</label>
                    <input id="amount" type="number">
                    <button id="incomeBtn">Add Income</button>
                    <button id="expenseBtn">Add Expense</button>
                </form>
            </div>
        </div>



        
        <script src="index.js"></script>
    </body>
</html>