<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>blogs</title>
    <script src="https://use.fontawesome.com/9eaaef4457.js"></script>
    <link rel="stylesheet" href="styles.css">


    <style>


    </style>
</head>

<body>

    <nav>
        <h1><i class="fa fa-home" aria-hidden="true"></i> users review</h1>
      
        <a href="create.php">Add a new idea</a>
    </nav>

    <div class="todos">
        <!-- inject blogs here from js -->
    </div>

    <script src="index.js"></script>
</body>

</html>