<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>blogs</title>
    <script src="https://use.fontawesome.com/9eaaef4457.js"></script>
    <link rel="stylesheet" href="styles.css">


    <style>

@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');

/* base styles */

body {
    background: #eee;
    font-family: 'Roboto';
    color: #444;
    max-width: 960px;
    margin: 100px auto;
    padding: 10px;
}

nav {
    display: flex;
    justify-content: space-around;
    margin-right: 10rem;
}

nav h1 {
    margin: 0;
}

nav a {
    color: white;
    text-decoration: none;
    background: #36cca2;
    padding: 10px;
    border-radius: 10px;
}

form {
    max-width: 200px;
}

input,
textarea {
    display: block;
    margin: 16px 0;
    padding: 6px 10px;
    width: 100%;
    border: 1px solid #ddd;
    font-family: 'Roboto';
}

textarea {
    min-height: 200px;
}
.todos{
    display:block;
    margin-left:10rem;
    border:groove;
    padding:3rem;
    background:white;
  
}

    </style>
</head>

<body>

    <nav class="nav1">
        <h1><i class="fa fa-home" aria-hidden="true"></i> users review</h1>
      
        <a href="create.php">Add a new idea</a>
    </nav>

    <div class="todos">
        <!-- inject blogs here from js -->
    </div>

    <script src="index1.js"></script>
</body>

</html>